package com.works.onedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.works.onedays.services.UserService;

@Controller
public class IncluderController {
	
	final UserService service;
	public IncluderController( UserService service ) {
		this.service = service;
	}
	
	@GetMapping("/menu")
	public String menu( Model model ) {
		model.addAttribute( "user", service.user() );
		return "inc/menu";
	}

}

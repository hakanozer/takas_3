package com.works.onedays.services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.works.onedays.entities.User;
import com.works.onedays.utils.Util;

@Service
public class UserService {

	@Autowired
	DriverManagerDataSource db;

	public final HttpServletRequest req;
	final HttpServletResponse res;

	public UserService(HttpServletRequest req, HttpServletResponse res) {
		this.req = req;
		this.res = res;
	}

	public boolean userLogin(User u) {

		boolean status = false;

		try {
			// select * from user where email = 'a@a.com' and password = '' or 1=1 --'
			// String sql = "select * from user where email = '"+u.getEmail()+"' and
			// password = '"+u.getPassword()+"' ";
			// Statement statement = db.getConnection().createStatement();
			// ResultSet rs = statement.executeQuery(sql);

			String sql_p = "select * from user where email = ? and password = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(sql_p);
			pre.setString(1, u.getEmail());
			pre.setString(2, u.getPassword());
			ResultSet rss = pre.executeQuery();

			status = rss.next();
			if (status) {
				u.setPassword(null);
				u.setName(rss.getString("name"));
				u.setUid(rss.getInt("uid"));
				req.getSession().setAttribute("user", u);

				// cookie control
				if (u.getRemember() != null && u.getRemember().equals("on")) {
					Cookie cookie = new Cookie("user_cookie", Util.sifrele("" + u.getUid(), 4));
					cookie.setMaxAge(60 * 60);
					res.addCookie(cookie);
				}

			}
			/*
			 * if ( rss.next() ) { System.out.println("User Login Success"); }else {
			 * System.out.println("User Login Fail"); }
			 */

		} catch (Exception e) {
			System.err.println("userLogin Error : " + e);
		}

		return status;

	}

	public String control(String page) {

		boolean status = req.getSession().getAttribute("user") != null;

		if (!status) {
			if (req.getCookies() != null) {

				Cookie[] cookies = req.getCookies();
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("user_cookie")) {
						try {
							int uid = Integer.parseInt(Util.sifreCoz(cookie.getValue(), 4));
							String sql = "select * from user where uid = ?";
							PreparedStatement pre = db.getConnection().prepareStatement(sql);
							pre.setInt(1, uid);
							ResultSet rs = pre.executeQuery();
							if (rs.next()) {
								User us = new User();
								us.setName(rs.getString("name"));
								req.getSession().setAttribute("user", us);
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
						break;
					}
				}

			}
		}

		String end_id = req.getSession().getId();
		System.out.println("end_id : " + end_id);

		status = req.getSession().getAttribute("user") != null;

		if (status) {
			return page;
		}

		return "redirect:/";

	}

	public User user() {

		User user = new User();
		boolean status = req.getSession().getAttribute("user") != null;
		if (status) {
			user = (User) req.getSession().getAttribute("user");
		}

		return user;

	}

	public void logout() {

		// single session remove
		req.getSession().removeAttribute("user");

		// all session remove
		req.getSession().invalidate();

		Cookie cookie = new Cookie("user_cookie", "");
		cookie.setMaxAge(0);
		res.addCookie(cookie);

	}

}

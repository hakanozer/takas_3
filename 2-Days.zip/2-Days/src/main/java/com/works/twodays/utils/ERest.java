package com.works.twodays.utils;

public enum ERest {
	
	status, message, result, errors, news;

}

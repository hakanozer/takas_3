package com.works.twodays.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.works.twodays.customannotation.City;

import lombok.Data;

@Entity
@Data
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer pid;
	
	@NotNull(message = "title @NotNull")
	@NotEmpty(message = "title @NotEmpty")
	private String title;
	
	@NotNull(message = "detail @NotNull")
	@NotEmpty(message = "detail @NotEmpty")
	private String detail;
	
	@Max(value = 10000, message = "price @Max 10000")
	@Min(value = 10, message = "price @Min 10")
	private Integer price;
	
	@City(message = "City is not allowed-")
	private String city;
	
	
}

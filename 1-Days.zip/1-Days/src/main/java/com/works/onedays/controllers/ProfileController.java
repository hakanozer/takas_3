package com.works.onedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.works.onedays.services.UserService;

@Controller
public class ProfileController {
	
	final UserService service;
	public ProfileController( UserService service ) {
		this.service = service;
	}

	@GetMapping("/profile")
	public String profile() {
		return service.control("profile");
	}
	
}

package com.works.onedays.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.onedays.entities.User;
import com.works.onedays.services.UserService;

@Controller
public class HomeController {

	final UserService uService;
	public HomeController( UserService uService ) {
		this.uService = uService;
	}
	
	
	@GetMapping("")
	public String home( Model model ) {
		String start_id = uService.req.getSession().getId();
		System.out.println("start_id : " + start_id);
		model.addAttribute("userValid", new User());
		return "home";
	}
	
	@GetMapping("/erros")
	public String homeRedirect() {
		return "home";
	}
	
	
	@PostMapping("/userInsert")
	public String userInsert( @Valid @ModelAttribute("userValid") User user, BindingResult br, Model model ) {
		
		if (br.hasErrors()) {
			//return "redirect:/";
		}else {
			boolean status = uService.userLogin(user);
			if (status) {
				return "redirect:/dashboard";
			}
		}
		
		return "home";
		
	}
	
	@GetMapping("/logout")
	public String logout() {
		uService.logout();
		return "redirect:/";
	}
	
	

}

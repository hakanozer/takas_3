package com.works.twodays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.works.twodays.entities.Customer;
import com.works.twodays.repositories.CustomerRepository;
import com.works.twodays.utils.ERest;

@RestController
@RequestMapping("/customer")
public class CustomerRestController {

	Map<ERest, Object> hm = new LinkedHashMap<>();
	final CustomerRepository cRepo;
	public CustomerRestController( CustomerRepository cRepo ) {
		this.cRepo = cRepo;
	}
	
	
	@PostMapping("/insert")
	public Map<ERest, Object> insert( @RequestBody Customer customer ) {
		hm.clear();

		customer.setCid(null);
		hm.put(ERest.status, true);
		hm.put(ERest.result, cRepo.saveAndFlush(customer));
		
		return hm;
	}
	
	
	@GetMapping("/list")
	public Map<ERest, Object> list() {
		hm.clear();
		
		hm.put(ERest.status, true);
		hm.put(ERest.result, cRepo.findAll());
		
		return hm;
	}
	
	
	@DeleteMapping("/delete")
	public Map<ERest, Object> delete( @RequestBody Customer customer ) {
		hm.clear();
		
		try {
			cRepo.deleteById(customer.getCid());
			hm.put(ERest.status, true);
			hm.put(ERest.result, customer.getCid());
		} catch (Exception e) {
			hm.put(ERest.status, false);
			hm.put(ERest.result, customer.getCid());
		}
		
		return hm;
	}
	
	
	@PutMapping("/update")
	public Map<ERest, Object> update( @RequestBody Customer customer ) {
		hm.clear();
				
		Optional<Customer> opCustomer = cRepo.findById(customer.getCid());
		if ( opCustomer.isPresent() ) {
			hm.put(ERest.status, true);
			hm.put(ERest.result, cRepo.saveAndFlush(customer));
		}else {
			hm.put(ERest.status, false);
			hm.put(ERest.message, "Cid not valid");
			hm.put(ERest.result, customer );
		}
		 
		return hm;
	}
	
	
	@PostMapping("/emailPass")
	public Map<ERest, Object> emailPass( @RequestBody Customer customer ) {
		hm.clear();
		
		Optional<Customer> oCustomer = cRepo.findByEmailAndPass(customer.getEmail(), customer.getPass());
		if ( oCustomer.isPresent() ) {
			hm.put(ERest.status, true);
			hm.put(ERest.result, oCustomer.get());
		}else {
			hm.put(ERest.status, false);
			hm.put(ERest.message, "Email or Password not valid");
		}
		
		return hm;
	}
	
	
	
	@GetMapping("/ageList")
	public Map<ERest, Object> ageList( @RequestBody Customer customer ) {
		hm.clear();
		
		List<Customer> oCustomer = cRepo.ageListCustomer(customer.getAge() );
		hm.put(ERest.status, true);
		hm.put(ERest.result, oCustomer );
		
		return hm;
	}
	
}

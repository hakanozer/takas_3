package com.works.twodays.restcontrollers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.works.twodays.entities.Product;
import com.works.twodays.props.Article;
import com.works.twodays.props.NewsData;
import com.works.twodays.repositories.ProductRepository;
import com.works.twodays.utils.ERest;
import com.works.twodays.utils.Util;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	Map<ERest, Object> hm = new LinkedHashMap<>();
	final ProductRepository pRepo;
	final CacheManager cacheManager;
	public ProductRestController( ProductRepository pRepo, CacheManager cacheManager ) {
		this.pRepo = pRepo;
		this.cacheManager = cacheManager;
	}
	
	
	@PostMapping("/insert")
	public Map<ERest, Object> insert( @Valid @RequestBody Product product ) {
		hm.clear();

		product.setPid(null);
		hm.put(ERest.status, true);
		hm.put(ERest.result, pRepo.saveAndFlush(product));
		
		cacheManager.getCache("list").clear();
		
		return hm;
	}
	
	
	@GetMapping("/list")
	@Cacheable("list")
	public Map<ERest, Object> list() {
		hm.clear();
		
		hm.put(ERest.status, true);
		hm.put(ERest.result, pRepo.findAll());
		hm.put(ERest.news, newsResult());

		return hm;
	}
	
	
	public List<Article> newsResult() {
		
		try {
			
			String url = "http://newsapi.org/v2/top-headlines?country=tr&apiKey=38a9e086f10b445faabb4461c4aa71f8";
			RestTemplate restTemplate = new RestTemplate();
			String stData = restTemplate.getForObject(url, String.class);
			
			Gson gson = new Gson();
			NewsData newsData = gson.fromJson(stData, NewsData.class);
			
			return newsData.getArticles();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
	}
	
	
	
	@DeleteMapping("/delete")
	public Map<ERest, Object> delete( @RequestBody Product product ) {
		hm.clear();
		
		try {
			pRepo.deleteById(product.getPid());
			hm.put(ERest.status, true);
			hm.put(ERest.result, product.getPid());
		} catch (Exception e) {
			hm.put(ERest.status, false);
			hm.put(ERest.result, product.getPid());
		}
		
		return hm;
	}
	
	
	@PutMapping("/update")
	public Map<ERest, Object> update( @RequestBody Product product ) {
		hm.clear();
				
		Optional<Product> opCustomer = pRepo.findById(product.getPid());
		if ( opCustomer.isPresent() ) {
			hm.put(ERest.status, true);
			hm.put(ERest.result, pRepo.saveAndFlush(product));
		}else {
			hm.put(ERest.status, false);
			hm.put(ERest.message, "Cid not valid");
			hm.put(ERest.result, product );
		}
		 
		return hm;
	}
	
	
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> handleFnc( MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		List<Map<String, String>> hLs = new ArrayList<>();
		List<ObjectError> ls = ex.getBindingResult().getAllErrors();
		for (ObjectError eItem : ls) {
			Map<String, String> ehm = new HashMap<>();
			String field = ((FieldError) eItem).getField();
			String message = eItem.getDefaultMessage();
			ehm.put("field", field);
			ehm.put("message", message);
			hLs.add(ehm);
		}
		
		hm.put("status", false);
		hm.put("errors", hLs);
		
		return hm;
	}
	
	


}

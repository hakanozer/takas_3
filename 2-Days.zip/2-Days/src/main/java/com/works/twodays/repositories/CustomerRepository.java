package com.works.twodays.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.works.twodays.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	
	@Query("select c from Customer c where c.age > ?1")
	List<Customer> ageListCustomer( int age );
	
	Optional<Customer> findByEmailAndPass( String Email, String Pass );
	
}

package com.works.twodays.customannotation;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CityValid implements ConstraintValidator<City, String> {

	List<String> cities = Arrays.asList("İstanbul", "Bursa", "Tekirdağ", "Edirne");
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		return cities.contains(value);
	}

}
